//
//  MyNiceLogger.h
//  MyNiceLogger
//
//  Created by Arslan Saeed on 22/02/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for MyNiceLogger.
FOUNDATION_EXPORT double MyNiceLoggerVersionNumber;

//! Project version string for MyNiceLogger.
FOUNDATION_EXPORT const unsigned char MyNiceLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyNiceLogger/PublicHeader.h>


